# 🔐 Password Strength Checker

This Python-based project checks the strength of a user's password using rules such as length, complexity, and character diversity.

## ✅ Features
- Length validation
- Special character check
- Character variety check
- Strength rating (Weak/Moderate/Strong)

## 📦 How to Run
1. Install Python 3.
2. Run the script:
   ```bash
   python password_checker.py
   ```

## 🧠 Learning Outcomes
- Regular Expressions
- Cybersecurity best practices
- Input validation and string handling
