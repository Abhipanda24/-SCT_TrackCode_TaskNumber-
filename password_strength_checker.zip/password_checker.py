import re

def check_password_strength(password):
    strength = 0
    suggestions = []

    # Length check
    if len(password) >= 8:
        strength += 1
    else:
        suggestions.append("Use at least 8 characters.")

    # Uppercase and lowercase
    if re.search(r'[A-Z]', password) and re.search(r'[a-z]', password):
        strength += 1
    else:
        suggestions.append("Use a mix of uppercase and lowercase letters.")

    # Digits
    if re.search(r'\d', password):
        strength += 1
    else:
        suggestions.append("Include at least one number.")

    # Special characters
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        strength += 1
    else:
        suggestions.append("Include at least one special character.")

    # Strength rating
    if strength == 4:
        return "Strong Password 💪", suggestions
    elif strength == 3:
        return "Moderate Password ⚠️", suggestions
    else:
        return "Weak Password ❌", suggestions

# Example usage
if __name__ == "__main__":
    user_password = input("Enter your password: ")
    result, tips = check_password_strength(user_password)
    print("\nResult:", result)
    if tips:
        print("Suggestions to improve:")
        for tip in tips:
            print("-", tip)
